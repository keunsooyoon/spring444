package com.carshop.controller;

import java.util.List;

public interface BoardRepository {
	
	List<BoardDTO> getAllBoardList();

}
