package com.carshop.board;

import java.util.List;

public interface BoardRepository {
	
	List<BoardDTO> getAllBoardList();

}
