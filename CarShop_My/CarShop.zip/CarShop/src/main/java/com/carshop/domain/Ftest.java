package com.carshop.domain;

import java.io.Serializable;

@SuppressWarnings("serial")
public class Ftest implements Serializable {

	
	// 명목상 지정하는 클래스
}
