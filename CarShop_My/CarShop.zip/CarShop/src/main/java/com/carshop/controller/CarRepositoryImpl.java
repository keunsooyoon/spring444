package com.carshop.controller;

import java.util.ArrayList;
import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class CarRepositoryImpl implements CarRepository {

	private List<CarDTO> listOfCars = new ArrayList<CarDTO>();
	
	public CarRepositoryImpl() {
		//기존 No DB 버전 코드 삭제
	}
	

	
	@Override	
	public List<CarDTO> getCarListByCategory(String category) {
		List<CarDTO> carsByCategory = new ArrayList<CarDTO>();
		for (int i = 0; i < listOfCars.size(); i++) {
			CarDTO carDTO = listOfCars.get(i);
			if (category.equalsIgnoreCase(carDTO.getCcate()))
				carsByCategory.add(carDTO);
		}
		return carsByCategory;
	}
	


	
	@Autowired
	SqlSessionTemplate sqlSessionTemplate;
	
	
	public void setNewCar(CarDTO car) {
		
		this.sqlSessionTemplate.insert("car.insert", car);
		
	}

	
	@Override
	public List<CarDTO> getAllCarList() {
		
		return this.sqlSessionTemplate.selectList("car.select_list");
	}
	
	
	public CarDTO getCarById(String cid) {
		
		return this.sqlSessionTemplate.selectOne("car.select_detail", cid);
	}
	
	public void setUpdateCar(CarDTO car) {
		
		if(car.getCfilename() != null) {
			this.sqlSessionTemplate.update("car.update1", car);
		} else if (car.getCfilename() == null) {
			this.sqlSessionTemplate.update("car.update2", car);
		}
	}
}
